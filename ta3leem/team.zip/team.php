  <?php
include 'header.php';
?>

 <body  id="toppage">
<!--   nav2  -->
<div class="slide2" >
    <img src="images/s2.png">
    <div class="spanpages">
        <div class="container">
            <h1>عملاؤنا</h1>
        </div>
    </div>
</div>

<!-- register form -->
    <div class="main-form margineq">
        <div class="container">
          <div class="row">
          <div class="row">
                <div class="col-md-3 col-sm-4">
                    <div class="card">
                       <a href="teamdetals.php">
                          <div class="personimg">
                             <img src="images/1.png">
                          </div>
                        <div class="content">
                            <h3>أحمد جمال </h3>
                        </div>
                        </a>
                    </div>
              </div>
           </div>
           </div>

        </div>
     </div>













  <?php
include 'footer.php';
?>
